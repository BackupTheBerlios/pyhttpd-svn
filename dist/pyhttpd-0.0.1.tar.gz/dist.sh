#!/bin/sh

tar -vcpz -f pyhttpd-0.0.1.tar.gz --exclude=.svn --exclude=*~ --exclude=*.pyc *
