##################################################################
#	pyHTTPd
#	$Id: webadmin_user.py 12 2006-03-12 10:05:42Z twenty-three $
#	(c) 2006 by Tim Taubert
##################################################################

import time

class user:
	logintime = 0
	ipaddr = ""
	
	def __init__(self, httpd):
		self.logintime = time.localtime()
		self.ipaddr = httpd.address_string()