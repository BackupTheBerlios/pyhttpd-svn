##################################################################
#	pyHTTPd
#	$Id: baseRoutines.py 12 2006-03-12 10:05:42Z twenty-three $
#	(c) 2006 by Tim Taubert
##################################################################

def parsePaths(httpd):
	# parse query string
	if httpd.path.find("?") > -1:
		httpd.path, httpd.query = httpd.path.split("?")
	else:
		httpd.query = ""